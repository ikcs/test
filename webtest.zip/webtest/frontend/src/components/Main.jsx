import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router';
const Main = () => {
  const navigate=useNavigate();
    const [data,setData]=useState([]);
    useEffect(()=>{
        const handel=async()=>{
        const response=await fetch('http://localhost:3000/notes',{
          method:'GET',
          headers:{
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        })
        const result=await response.json()
        console.log(result);
        setData(result.notes)
    }
    handel()
    console.log(data);
    },[])
    const create=async()=>{
      navigate("/make");
    }
  return (
    <div>
      <div>
        <button onClick={()=>{create();}}>Create</button>
      </div>
      {
        data.map(item=>(
          <div key={item._id}>
            <h1>{item.title}</h1>
            <p>{item.content}</p>
          </div>
        ))
      }
    </div>
  )
}

export default Main
