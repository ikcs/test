import React, { useState } from 'react'
import { useNavigate } from 'react-router'

const Signup = () => {
  const navigate = useNavigate()
  const [Name,setName]=useState('')
  const [Email, setEmail]=useState('')
  const [Password, setPassword]=useState('')
  const handleSubmit=async(e)=>{
    e.preventDefault()
    console.log(Name,Email,Password)

    try{
      const response=await fetch('http://localhost:8080/auth/signup',{
        method:'POST',
        headers:{
          'Content-Type':'application/json',
        },
        body:JSON.stringify({Name,Email,Password}),
      })
        const data=await response.json()
        navigate('/')
    }catch(error){
      console.error(error)
    }
  }
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Name" value={Name} onChange={(e)=>setName(e.target.value)} required/>
        <input type="email" placeholder="Email" value={Email} onChange={(e)=>setEmail(e.target.value)} required/>
        <input type="password" placeholder="Password" value={Password} onChange={(e)=>setPassword(e.target.value)} required/>
        <button type="submit">Submit</button>
      </form>
    </div>
  )
}

export default Signup
