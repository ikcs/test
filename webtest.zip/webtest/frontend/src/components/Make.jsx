import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router';

const Make = () => {
    const [title,setTitle]=useState("");
    const [content,setContent]=useState("");

    const handleChange =async (e) => {
        e.preventDefault();
        console.log(localStorage.getItem('token'))
        const response=await fetch('http://localhost:5000/notes',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer'+localStorage.getItem('token')  // Bearer token is needed for authenticated requests
                },
                body: JSON.stringify({title,content})
            }
        );
    }
  return (
    <div>
        <form onSubmit={()=>{handleChange(e)}}>
            <input type="text" placeholder="Title" value={title} onChange={(e)=>setTitle(e.target.value)}/>
            <textarea placeholder="Content" value={content} onChange={(e)=>setContent(e.target.value)}/>
            <button type="submit" onClick={handleChange}>Save</button>
        </form>
    </div>
  )
}

export default Make
