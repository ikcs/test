const express=require('express');
const router=express.Router();
const User=require('../model/user')
const jwt = require('jsonwebtoken');
router.post('/signup',async(req,res)=>{
    console.log(req.body,"*")
    const {Name,Email,Password}=req.body;
    const user=new User({Name,Email,Password});
    await user.save();
    res.json({Result:true})
})
router.get('/login',async(req, res) => {
    console.log(req.body);
    const { Email, Password } = req.body;
    try {
        const user = await User.findOne({ Email });
        if (!user || Password!==user.Password) {
            return res.status(401).json({ Result: false, message: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: user._id },'Notes', { expiresIn: '4h' });
        res.json({ Result: true, token });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }}
)

module.exports=router;