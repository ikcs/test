const express=require('express')
const app= express()
const cors= require('cors')
const mongoose= require('mongoose')

app.use(cors())
app.use(express.json())

mongoose.connect('mongodb://localhost:27017/Notes')
    .then(()=> app.listen(8080))

const auth=require('./routes/auth')
const notes=require('./routes/notes')

app.use('/auth',auth)

app.use('/notes',notes)