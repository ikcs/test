const express= require('express')
const router=express.Router()
const jwt=require('jsonwebtoken')
const User=require('../models/User')

router.post('/signup',async(req,res)=>{
    const{Name,Email,Password}=req.body;
    const user=new User({Name,Email,Password})
    await user.save();
    res.json({Result:true})
})

router.post('/login',async(req,res)=>{
    const{Email,Password}=req.body;
    const user=await User.findOne({Email});
    if(!user || user.Password !== Password)
        return res.status(401).json({Result:false,message:'Invalid Email or Password'})
    const token=jwt.sign({_id:user._id},"Create",{expiresIn:'1h'})
    res.json({Result:true,token})
})

module.exports=router;