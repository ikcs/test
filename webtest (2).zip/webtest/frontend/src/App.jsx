import { useState } from 'react'
import { BrowserRouter, Routes, Route } from "react-router"
import './App.css'
import Home from './components/Home'
import Login from './components/Login'
import SignUp from './components/Signup'
import Main from './components/Main'
import Create from './components/Create'
import Edit from './components/Edit'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/main" element={<Main />} />
        <Route path="/create" element={<Create />} />
        <Route path="/edit/:id" element={<Edit />} />
      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
