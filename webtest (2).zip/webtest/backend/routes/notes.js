const express = require('express')
const router = express.Router()
const Notes=require('../models/Notes')
const verify = require('./verify')

router.get('/',verify,async(req,res)=>{
    try {
        const notes = await Notes.find({User:req.user._id})
        res.json(notes)
    } catch (error) {
        res.status(500).json({error:error.message})
    }
})

router.get('/:id',verify,async(req,res)=>{
    try {
        const note = await Notes.findById(req.params.id)
        if(!note) return res.status(404).json({message:'Note not found'})
        res.json(note)
    } catch (error) {
        res.status(500).json({error:error.message})
    }
})

router.post('/',verify,async(req,res)=>{
    const newNote=new Notes({...req.body,User:req.user._id})
    console.log(newNote)
    try {
        const savedNote = await newNote.save()
        res.json(savedNote)
    } catch (error) {
        res.status(500).json({error:error.message})
    }
})

router.put('/:id',verify,async(req,res)=>{
    try {
        const note = await Notes.findByIdAndUpdate(req.params.id,req.body,{new:true})
        if(!note) return res.status(404).json({message:'Note not found'})
        res.json(note)
    } catch (error) {
        res.status(500).json({error:error.message})
    }
})

router.delete('/:id',verify,async(req,res)=>{
    try {
        const note = await Notes.findByIdAndDelete(req.params.id)
        if(!note) return res.status(404).json({message:'Note not found'})
        res.json({message:'Note deleted'})
    } catch (error) {
        res.status(500).json({error:error.message})
    }
})

module.exports = router