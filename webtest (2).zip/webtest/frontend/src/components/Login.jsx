import React, { useState } from 'react'
import { useNavigate } from 'react-router'

const Login = () => {
  const navigate = useNavigate()
  const [Email, setEmail]=useState('')
  const [Password, setPassword]=useState('')
  const handleSubmit=async(e)=>{
    e.preventDefault()
    console.log(Email,Password)

    try{
      const response=await fetch('http://localhost:8080/auth/login',{
        method:'POST',
        headers:{
          'Content-Type':'application/json',
        },
        body:JSON.stringify({Email,Password}),
      })
        const data=await response.json()
        localStorage.setItem('token',data.token)
        navigate('/main')
    }catch(error){
      console.error(error)
    }
  }
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input type="email" placeholder="Email" value={Email} onChange={(e)=>setEmail(e.target.value)} required/>
        <input type="password" placeholder="Password" value={Password} onChange={(e)=>setPassword(e.target.value)} required/>
        <button type="submit">Submit</button>
      </form>
    </div>
  )
}

export default Login
