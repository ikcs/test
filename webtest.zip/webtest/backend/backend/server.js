const express = require("express");
const app = express();
const connectDB = require("./config/db")
const cors=require('cors');
require('dotenv').config()

app.use(cors());
app.use(express.json());

const authRoutes = require('./routes/authRoutes')
const noteRoutes = require('./routes/notesRoutes')

app.use("/users",authRoutes);
app.use("/notes",noteRoutes);

app.listen(process.env.port || 5000, async () =>{
     await connectDB();
     console.log(`Server connected successfully..`)
});
