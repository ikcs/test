import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router';

const Signup = () => {
    const navigate=useNavigate();
    const [Name,setName]=useState("");
    const [Email,setEmail]=useState("");
    const [Password,setPassword]=useState("");

    const handleSubmit = async (event) => {
      event.preventDefault();
      
      try {
          const response = await fetch('http://localhost:5000/users/register', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json' // Add content type header
              },
              body: JSON.stringify({ name: Name, email: Email, password: Password })
          });
  
          if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
          }
  
          const data = await response.json();
  
          if (!data.Result) {
              alert("Something went wrong");
          } else {
             navigate('/login'); // Redirect to login page after successful registration
              alert("You have successfully signed up!");
          }
      } catch (error) {
          console.error("Error during registration:", error);
          alert("An error occurred while signing up. Please try again.");
      }
  };
  
  return (
    <div>
      <form onSubmit={(e)=>handleSubmit(e)}>
        <label>Name:</label>
        <input type="text" value={Name} onChange={(e)=>setName(e.target.value)} />
        <label>Email:</label>
        <input type="text" value={Email} onChange={(e)=>setEmail(e.target.value)} />
        <label>Password:</label>
        <input type="password" value={Password} onChange={(e)=>setPassword(e.target.value)} />
        <button type="submit">Sign Up</button>
      </form>
    </div>
  )
}

export default Signup
