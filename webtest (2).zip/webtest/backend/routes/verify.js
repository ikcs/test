const jwt=require('jsonwebtoken')

const verify=(req, res, next) =>{
    const token=req.headers.authorization && req.headers.authorization.split(' ')[1];
    // console.log(token)
    if(!token) return res.status(401).json({ message: 'Access token missing' });

    const data=jwt.verify(token,"Create")
    req.user=data;
    next();
}

module.exports=verify;