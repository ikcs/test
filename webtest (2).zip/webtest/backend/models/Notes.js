const mongoose = require('mongoose');
const Schema=mongoose.Schema;

const NotesSchema=new Schema({
    Title:{
        type:String,
        required:true,
    },
    Content:{
        type:String,
        required:true,
    },
    images:{
        type:String,
        trim:true,
    },
    User:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    }
})
const Notes=mongoose.model("Notes",NotesSchema);
module.exports =Notes;