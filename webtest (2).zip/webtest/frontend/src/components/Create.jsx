import React, { useState } from 'react'
import { useNavigate } from 'react-router'

const Create = () => {
  const navigate = useNavigate()
  const [Title, setTitle] = useState('')
  const [Content, setContent] = useState('')
  const [images, setImages] = useState([])

  const handleSubmit = async (e) => {
    e.preventDefault()

    const formData = new FormData()
    formData.append('Title', Title)
    formData.append('Content', Content)

    // Append multiple images
    images.forEach((image) => {
      formData.append('images', image)
    })

    const response = await fetch('http://localhost:8080/notes', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`, // No 'Content-Type' for FormData
      },
      body: formData,
    })

    if (response.ok) {
      navigate('/main')
    } else {
      console.error("Error uploading note")
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <input
          type="text"
          value={Title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Title"
        />
        <textarea
          value={Content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Content"
        />
        <input
          type="file"
          multiple
          onChange={(e) => setImages(Array.from(e.target.files))}
        />
        <button type="submit">Create</button>
      </form>
    </div>
  )
}

export default Create
