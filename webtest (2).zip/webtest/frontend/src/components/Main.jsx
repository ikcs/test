import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'

const Main = () => {
  const navigate = useNavigate()
  const [notes,setNotes]=useState([])
  useEffect(()=>{
    console.log(localStorage.getItem('token'))
    const get=async()=>{
      try{
        const response = await fetch('http://localhost:8080/notes', {
          headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token'),
          },
        });
        const data=await response.json()
        console.log(data);
        setNotes(data)
      }catch(error){
        setError(error.message)
      }
    }
    get()
  },[])
  const handelDelete=async(id)=>{
    try{
      await fetch(`http://localhost:8080/notes/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + localStorage.getItem('token'),
        },
      });
      const updatedNotes=notes.filter(note=>note._id!==id)
      setNotes(updatedNotes)
    }catch(error){
      setError(error.message)
    }
  }
  return (
    <div>
      <button onClick={()=>navigate('/create')}>create</button>
      {
        notes.map(note=>(
          <div key={note._id}>
            <h2>{note.Title}</h2>
            <p>{note.Content}</p>
            {note.image ? <img src={note.image}/>:null}
            <button onClick={()=>navigate(`/edit/${note._id}`)}>Edit</button>
            <button onClick={()=>handelDelete(note._id)}>Delete</button>
          </div>
        ))
      }
    </div>
  )
}

export default Main
