const Note = require('../models/notesModel');

const getNotes = async (req, res) => {
  const notes = await Note.find({ user: req.user.id });
  res.status(200).json(notes);
};

const createNote = async (req, res) => {
  const note = await Note.create({
    user: req.user.id,
    title: req.body.title,
    content: req.body.content,
  });

  res.status(201).json(note);
};

const updateNote = async (req, res) => {
  const note = await Note.findById(req.params.id);
  const updatedNote = await Note.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.status(200).json(updatedNote);
};

const deleteNote = async (req, res) => {
  const note = await Note.findById(req.params.id);
  await note.deleteOne();
  res.status(200).json({ id: req.params.id });
};

module.exports = {
  getNotes,
  createNote,
  updateNote,
  deleteNote,
};
