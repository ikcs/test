import React,{useState,useEffect} from 'react';
import { useNavigate } from 'react-router';

const Home = () => {
  const navigate=useNavigate();
  function onClickHandler(target){
    if (target==='Login')navigate('/Login');
    else navigate('/signup');
  }

  return (
    <div >
      <h1 >Welcome</h1>
      <button
        onClick={() => onClickHandler('Login')}
      >
        Login
      </button>
      <button
        onClick={() => onClickHandler('SignUp')}
      >
        Sign Up
      </button>
    </div>
  );
};

export default Home;
