const express=require('express');
const router=express.Router();
const User=require('../model/user');
const Notes=require('../model/notes');
const jwt = require('jsonwebtoken');
router.post('/create',async(req,res)=>{
    const {token}=req.body;
    const verify=jwt.verify(token, 'Notes');
    if(!verify) return res.status(403).json({Result:false});
    const notes=req.body.notes;
    const id=verify.id;
    const note=new Notes({User:id,text:notes});
    await note.save();
    res.json({Result:true})
})
router.get('/get',async(req,res)=>{
    const {token}=req.body;
    const verify=jwt.verify(token, 'Notes');
    if(!verify) return res.status(403).json({Result:false});
    const id=verify.id
    const data=await Notes.findById({User:id});
    res.json({Result:true,data})
})
router.put('/update',async(req,res)=>{
    const {token}=req.body;
    const verify=jwt.verify(token, 'Notes');
    if(!verify) return res.status(403).json({Result:false});
    const id=verify.id
    const data=await Notes.findByIdAndUpdate({User:id},{$set:{text:req.body.text}});
    res.json({Result:true})
})
router.delete('/delete',async(req,res)=>{
    const {token}=req.body;
    const verify=jwt.verify(token, 'Notes');
    if(!verify) return res.status(403).json({Result:false});
    const id=verify.id
    const notesId=req.body.notes.id;
    const data=await Notes.findByIdAndDelete({_id:notesId});
    res.json({Result:true})
})
module.exports=router;