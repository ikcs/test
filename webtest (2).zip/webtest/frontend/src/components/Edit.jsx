import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router'
import { useParams } from 'react-router';

const Edit = () => {
    const {id}=useParams()
    const navigate = useNavigate();
    const [Title,setTitle]=useState('');
    const [Content,setContent]=useState('');
    const [image,setImage]=useState('');
    useEffect(()=>{
        const get=async()=>{
            try{
                const response = await fetch(`http://localhost:8080/notes/${id}`, {
                  headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('token'),
                  },
                })
                const data = await response.json();
                setTitle(data.Title)
                setContent(data.Content)
                setImage(data.image)
            }catch(err){
                console.log(err)
            }
        }
        get()
    },[])
    const handleSubmit=async(e)=>{
        e.preventDefault();
        try{
            const response = await fetch(`http://localhost:8080/notes/${id}`, {
                method: 'PUT',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer '+localStorage.getItem('token'),
                },
                body: JSON.stringify({Title,Content,image}),
            })
            if(response.ok){
                navigate('/main')
            }
        }catch(err){
            console.log(err)
        }
    }
  return (
    <div>
        <form onSubmit={handleSubmit}>
            <input type="text" value={Title} onChange={(e) => setTitle(e.target.value)}/>
            <textarea value={Content} onChange={(e) => setContent(e.target.value)}/>
                <input type="file" onChange={(e) => setImage(e.target.files[0])}/>
            <button type="submit">Update</button>
        </form>
        <button onClick={()=>navigate(`/main`)}>Back</button>
    </div>
  )
}

export default Edit

