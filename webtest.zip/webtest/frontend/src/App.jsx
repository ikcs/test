import { useState } from 'react'
import { BrowserRouter, Routes, Route } from "react-router";
import Home from './components/Home'
import Signup from './components/Signup'
import Login from './components/Login'
import Main from './components/Main'
import Make from './components/Make'
function App() {

  return (
    <>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/main" element={<Main />} />
        <Route path="/make" element={<Make />} />
      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
