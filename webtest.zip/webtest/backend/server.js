const express=require('express');
const app= express();
const mongoose= require('mongoose');
const cors= require('cors');

const PORT=3000;
mongoose.connect('mongodb://localhost:27017/notes')
    .then(() => {
        console.log('Connected to MongoDB');
        app.listen(PORT, () => {
            console.log('Server is listening on port', PORT);
        });
    })
    .catch(err => {
        console.error('Error connecting to MongoDB:', err.message);
    });

app.use(cors());

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const auth=require('./routes/auth')
app.use('/auth',auth);
