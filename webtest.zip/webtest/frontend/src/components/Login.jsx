import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router';

const Login = () => {
    const navigate=useNavigate();
    const [Name,setName]=useState("");
    const [Email,setEmail]=useState("");
    const [Password,setPassword]=useState("");
    const handleSubmit = async (event) => {
      event.preventDefault();
      try {
          const response = await fetch('http://localhost:5000/users/login', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json' // Add content type header
              },
              body: JSON.stringify({email: Email, password: Password })
          });
  
          if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
          }
  
          const data = await response.json();
  
          
          localStorage.setItem('token',data.token)
          navigate('/main');
      } catch (error) {
         alert("An error occurred: " + error.message);
      }
  };
  return (
    <div>
      <form onSubmit={(e)=>handleSubmit(e)}>
        <label>Email:</label>
        <input type="text" value={Email} onChange={(e)=>setEmail(e.target.value)} />
        <label>Password:</label>
        <input type="password" value={Password} onChange={(e)=>setPassword(e.target.value)} />
        <button type="submit">Sign Up</button>
      </form>
    </div>
  )
}

export default Login
