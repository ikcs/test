const express = require('express');
const router = express.Router();
const { getNotes, createNote, updateNote, deleteNote } = require('../controllers/noteController');
const { protect } = require('../middleware/authMiddleware');

router.get('/',protect,getNotes);
router.put("/", protect, updateNote);
router.delete("/", protect, deleteNote);
router.post("/", protect, createNote);

module.exports = router;